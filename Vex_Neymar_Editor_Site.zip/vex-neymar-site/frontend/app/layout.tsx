import type { Metadata } from 'next';
import './style.css';
export const metadata: Metadata = { title: 'Vex Neymar Editor PRO', description: 'Editor de vídeos com inteligência artificial' };
export default function RootLayout({ children }: Readonly<{children: React.ReactNode}>) { return <html lang="pt-BR"><body>{children}</body></html>; }
