const editorUrl = process.env.NEXT_PUBLIC_EDITOR_URL;
export default function Home() {
 return <main>
  <header><img src="/logo-vex-neymar.png" alt="Vex Neymar Editor"/><div><span className="tag">EDITOR DE VÍDEOS COM IA</span><h1>Vex Neymar <b>Editor PRO</b></h1><p>Envie seu vídeo, descreva a edição e deixe o editor fazer o trabalho.</p></div></header>
  <section className="features"><article>🎨 <b>Filtros e cores</b><small>Visual vibrante e estilo cinema</small></article><article>📱 <b>Formato TikTok</b><small>Vídeos verticais para redes sociais</small></article><article>🐢 <b>Câmera lenta</b><small>Controle de velocidade e cortes</small></article></section>
  <section className="editor"><h2>Seu editor</h2>{editorUrl ? <iframe src={editorUrl} title="Editor de vídeos Vex Neymar" allow="camera; microphone"/> : <div className="setup"><b>Quase pronto!</b><p>O site está preparado. Falta publicar o motor de edição e adicionar o endereço dele na variável <code>NEXT_PUBLIC_EDITOR_URL</code> da Vercel.</p></div>}</section>
  <footer>VEX NEYMAR EDITOR PRO · EDITE • CRIE • INOVE</footer>
 </main>
}
