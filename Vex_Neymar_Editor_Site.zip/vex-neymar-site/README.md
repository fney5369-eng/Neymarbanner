# Vex Neymar Editor PRO — publicação

O projeto foi separado em duas partes porque a Vercel é adequada para o site, mas o processamento de vídeos com Python + FFmpeg precisa de um serviço de backend persistente.

## 1. Publicar o motor de edição (Render)
1. Crie um repositório GitHub e envie a pasta `backend`.
2. No Render, crie um serviço **New > Web Service** ligado ao repositório.
3. Defina `Root Directory` como `backend` e escolha **Docker**.
4. Faça o deploy e copie a URL pública do serviço.

## 2. Publicar o site (Vercel)
1. Importe o mesmo repositório na Vercel.
2. Defina `Root Directory` como `frontend`.
3. Em Environment Variables, crie `NEXT_PUBLIC_EDITOR_URL` com a URL pública do serviço Render.
4. Faça Deploy.

## Notas importantes
- O notebook original tinha chamadas a `run()` e `probe()` sem as definições correspondentes. Elas foram adicionadas ao backend.
- A interface de edição Gradio é incorporada dentro do site Vercel.
- O recurso de entender pedidos por Claude é opcional e exige uma chave da API Anthropic inserida pelo próprio usuário na tela do editor. Sem chave, o reconhecimento por palavras-chave funciona.
- A melhoria de imagem/rosto do código original usa filtros OpenCV, não restauração neural real. A seleção de melhores momentos usa picos de volume do áudio como aproximação.
- O deploy não foi executado nesta conta; será necessário conectar o GitHub ao Render e à Vercel e concluir essas etapas.
