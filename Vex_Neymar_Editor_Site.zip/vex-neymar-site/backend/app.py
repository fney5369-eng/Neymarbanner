import os, re, glob, shutil, tempfile, json, urllib.request, wave, subprocess, json
import cv2, gradio as gr, numpy as np

def run(cmd):
    p = subprocess.run(cmd, capture_output=True, text=True)
    if p.returncode != 0:
        raise RuntimeError((p.stderr or p.stdout or 'Falha no FFmpeg')[-2500:])
    return p

def probe(path):
    p = subprocess.run(["ffprobe", "-v", "error", "-show_streams", "-show_format", "-of", "json", path], capture_output=True, text=True)
    if p.returncode != 0:
        raise RuntimeError('Não foi possível ler este vídeo.')
    data = json.loads(p.stdout)
    streams = data.get('streams', [])
    v = next((x for x in streams if x.get('codec_type') == 'video'), None)
    if not v: raise RuntimeError('O arquivo não contém uma faixa de vídeo válida.')
    a = any(x.get('codec_type') == 'audio' for x in streams)
    fmt = data.get('format', {})
    fps_text = v.get('avg_frame_rate', '30/1')
    try:
        n,d = fps_text.split('/')
        fps = float(n)/max(float(d),1)
    except Exception: fps = 30.0
    return int(v.get('width', 1280)), int(v.get('height', 720)), max(1.0, min(fps, 60.0)), a, float(fmt.get('duration', 0) or 0)

FONT = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"
GRADES = {
    "Nenhum": None,
    "Natural": "eq=contrast=1.05:saturation=1.1",
    "Edit vibrante": "eq=contrast=1.12:saturation=1.4:brightness=0.02:gamma=1.05",
    "Cinema (azul e laranja)": "eq=contrast=1.1:saturation=1.0,colorbalance=rs=-0.08:bs=0.08:rh=0.08:bh=-0.08",
    "TV esportiva": "eq=contrast=1.08:saturation=1.25,unsharp=5:5:0.8:3:3:0.3",
    "Preto e branco": "hue=s=0,eq=contrast=1.15",
}
FORMATS = ["Original", "Vertical 9:16 (TikTok)", "Horizontal 16:9"]
SLOWS = ["1x", "0.75x", "0.5x"]
# ordem: aprimorar, rostos, ruído, cor, áudio, silêncios, melhores momentos, estabilizar, nitidez, vinheta, formato, câmera lenta
RECIPES = {
    "Personalizado": None,
    "⚡ Edit pro para TikTok (vertical)": (True, True, False, "Edit vibrante", True, False, False, True, True, True, FORMATS[1], "1x"),
    "🎬 Cinema": (True, False, True, "Cinema (azul e laranja)", True, False, False, True, False, True, FORMATS[0], "1x"),
    "🏆 Jogo completo → melhores momentos": (False, False, False, "TV esportiva", True, False, True, False, True, False, FORMATS[2], "1x"),
    "🐢 Câmera lenta do lance": (True, False, False, "Edit vibrante", True, False, False, True, True, False, FORMATS[0], "0.5x"),
    "🧹 Só limpar (rápido)": (False, False, True, "Natural", True, True, False, False, False, False, FORMATS[0], "1x"),
}

def find_highlights(path, work, n, seg):
    """Acha os momentos mais 'barulhentos' (torcida, gol, narrador) e devolve trechos (início, fim)."""
    wav = os.path.join(work, "a.wav")
    run(["ffmpeg", "-y", "-i", path, "-vn", "-ac", "1", "-ar", "8000", "-f", "wav", wav])
    w = wave.open(wav)
    sr = w.getframerate()
    data = np.frombuffer(w.readframes(w.getnframes()), dtype=np.int16).astype(np.float32)
    w.close()
    hop = sr // 2
    nwin = len(data) // hop
    if nwin < 4:
        return []
    rms = np.sqrt((data[:nwin * hop].reshape(nwin, hop) ** 2).mean(axis=1))
    smooth = np.convolve(rms, np.ones(6) / 6, mode="same")
    dur = len(data) / sr
    picks = []
    for idx in np.argsort(smooth)[::-1]:
        t = idx * 0.5
        if all(abs(t - p) > seg for p in picks):
            picks.append(t)
        if len(picks) >= n:
            break
    segs = [(max(0.0, t - seg * 0.6), min(dur, t + seg * 0.4)) for t in sorted(picks)]
    return segs

def cut_silence(inp, out):
    _, _, _, has_audio, dur = probe(inp)
    if not has_audio:
        return inp
    r = subprocess.run(["ffmpeg", "-i", inp, "-af", "silencedetect=noise=-35dB:d=0.7", "-f", "null", "-"],
                       capture_output=True, text=True)
    starts = [float(x) for x in re.findall(r"silence_start: ([\d.]+)", r.stderr)]
    ends = [float(x) for x in re.findall(r"silence_end: ([\d.]+)", r.stderr)]
    if not starts:
        return inp
    while len(ends) < len(starts):
        ends.append(dur)
    keep, cur = [], 0.0
    for s, e in zip(starts, ends):
        if s - cur > 0.1:
            keep.append((cur, min(s + 0.15, dur)))
        cur = max(e - 0.15, 0)
    if dur - cur > 0.1:
        keep.append((cur, dur))
    if not keep:
        return inp
    expr = "+".join(f"between(t,{a:.3f},{b:.3f})" for a, b in keep)
    run(["ffmpeg", "-y", "-i", inp,
         "-vf", f"select='{expr}',setpts=N/FRAME_RATE/TB",
         "-af", f"aselect='{expr}',asetpts=N/SR/TB",
         "-c:v", "libx264", "-preset", "fast", "-crf", "18", "-pix_fmt", "yuv420p",
         "-c:a", "aac", "-b:a", "192k", out])
    return out

def process(video, up_on, face_on, den, grade, aud, sil, hl, stab, sharp, vig, fmt, slow,
            res, mx, n_hl, seg_len, wm, fade, progress=gr.Progress()):
    if not video:
        raise gr.Error("Envie um vídeo primeiro.")
    try:
        S = 720 if res == "720p" else 1080
        work = tempfile.mkdtemp(prefix="vex_")
        _, _, _, has_audio, _ = probe(video)
        notes = []

        # 1) escolhe os melhores momentos (se pedido)
        sel = ""
        if hl:
            if not has_audio:
                notes.append("Sem áudio: não deu para achar melhores momentos.")
            else:
                progress(0.02, desc="Procurando os melhores momentos...")
                segs = find_highlights(video, work, int(n_hl), float(seg_len))
                if segs:
                    sel = "+".join(f"between(t,{a:.3f},{b:.3f})" for a, b in segs)
                    notes.append(f"{len(segs)} melhores momentos escolhidos pelo barulho da torcida/narração.")

        # 2) etapa de filtros (uma só passada)
        progress(0.06, desc="Aplicando cor, estabilização e áudio...")
        vf, af = [], []
        if sel:
            vf.append(f"select='{sel}',setpts=N/FRAME_RATE/TB")
            af.append(f"aselect='{sel}',asetpts=N/SR/TB")
        if stab: vf.append("deshake")
        if den: vf.append("hqdn3d=4:3:6:4.5")
        if GRADES.get(grade): vf.append(GRADES[grade])
        if sharp: vf.append("unsharp=5:5:0.9:3:3:0.4")
        if vig: vf.append("vignette=PI/5")
        vf.append(f"scale='if(gt(iw,ih),-2,min(iw,{S}))':'if(gt(iw,ih),min(ih,{S}),-2)'")
        sp = float(slow.replace("x", ""))
        if sp < 1:
            vf.append(f"setpts=PTS/{sp}")
        if aud: af.append("highpass=f=80,afftdn=nr=12:nf=-30,loudnorm=I=-16:TP=-1.5:LRA=11")
        if sp < 1: af.append(f"atempo={sp}")
        cmd = ["ffmpeg", "-y", "-i", video]
        if not sel:
            cmd += ["-t", str(int(mx))]
        cmd += ["-vf", ",".join(vf)]
        if has_audio and af:
            cmd += ["-af", ",".join(af)]
        s1 = os.path.join(work, "s1.mp4")
        cmd += ["-c:v", "libx264", "-preset", "fast", "-crf", "18", "-pix_fmt", "yuv420p",
                "-c:a", "aac", "-b:a", "192k", s1]
        run(cmd)
        current = s1

        if sil:
            progress(0.12, desc="Cortando silêncios...")
            current = cut_silence(current, os.path.join(work, "s2.mp4"))

        # 3) melhoria local de imagem (sem baixar modelos grandes)
        if up_on or face_on:
            w, h, fps, _, _ = probe(current)
            fdir, odir = os.path.join(work, "in"), os.path.join(work, "out")
            os.makedirs(fdir); os.makedirs(odir)
            progress(0.15, desc="Preparando os quadros...")
            run(["ffmpeg", "-y", "-i", current, "-q:v", "2", os.path.join(fdir, "%06d.jpg")])
            frames = sorted(glob.glob(os.path.join(fdir, "*.jpg")))
            n = len(frames)
            if n == 0:
                raise RuntimeError("Não consegui extrair quadros deste vídeo. Tente outro arquivo MP4.")
            face_cascade = None
            if face_on:
                cascade_path = os.path.join(cv2.data.haarcascades, "haarcascade_frontalface_default.xml")
                face_cascade = cv2.CascadeClassifier(cascade_path)
            clahe = cv2.createCLAHE(clipLimit=1.5, tileGridSize=(8, 8))
            for i, f in enumerate(frames):
                img = cv2.imread(f)
                if img is None:
                    continue
                if up_on:
                    lab = cv2.cvtColor(img, cv2.COLOR_BGR2LAB)
                    l, aa, bb = cv2.split(lab)
                    l = clahe.apply(l)
                    img = cv2.cvtColor(cv2.merge((l, aa, bb)), cv2.COLOR_LAB2BGR)
                    blur = cv2.GaussianBlur(img, (0, 0), 1.0)
                    img = cv2.addWeighted(img, 1.18, blur, -0.18, 0)
                if face_cascade is not None and not face_cascade.empty():
                    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
                    faces = face_cascade.detectMultiScale(gray, scaleFactor=1.1,
                                                          minNeighbors=5, minSize=(40, 40))
                    for (x, y, fw, fh) in faces:
                        roi = img[y:y+fh, x:x+fw]
                        lab = cv2.cvtColor(roi, cv2.COLOR_BGR2LAB)
                        ll, aa, bb = cv2.split(lab)
                        ll = clahe.apply(ll)
                        img[y:y+fh, x:x+fw] = cv2.cvtColor(
                            cv2.merge((ll, aa, bb)), cv2.COLOR_LAB2BGR)
                cv2.imwrite(os.path.join(odir, os.path.basename(f)), img,
                            [cv2.IMWRITE_JPEG_QUALITY, 94])
                if i % 5 == 0:
                    progress(0.15 + 0.7 * (i + 1) / max(n, 1),
                             desc=f"Melhorando imagem... quadro {i+1}/{n}")
            progress(0.88, desc="Montando o vídeo...")
            enhanced = os.path.join(work, "enhanced.mp4")
            run(["ffmpeg", "-y", "-framerate", str(fps), "-i", os.path.join(odir, "%06d.jpg"),
                 "-i", current, "-map", "0:v", "-map", "1:a?",
                 "-vf", "scale=trunc(iw/2)*2:trunc(ih/2)*2",
                 "-c:v", "libx264", "-preset", "fast", "-crf", "18",
                 "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "192k",
                 "-shortest", enhanced])
            current = enhanced

        # 4) acabamento: formato, marca d'água, fade
        wm_clean = re.sub(r"[^\w\s@.\-]", "", wm or "").strip()
        if fmt != FORMATS[0] or wm_clean or fade:
            progress(0.93, desc="Acabamento final...")
            _, _, _, a2, d2 = probe(current)
            ev = lambda x: int(x) // 2 * 2
            if fmt == FORMATS[1]:
                W, H = S, ev(S * 16 / 9)
            elif fmt == FORMATS[2]:
                W, H = ev(S * 16 / 9), S
            else:
                W = H = None
            if W:
                fc = (f"[0:v]split[a][b];[a]scale={W}:{H}:force_original_aspect_ratio=increase,crop={W}:{H},"
                      f"boxblur=25:5[bg];[b]scale={W}:{H}:force_original_aspect_ratio=decrease[fg];"
                      f"[bg][fg]overlay=(W-w)/2:(H-h)/2[v0]")
            else:
                fc = "[0:v]null[v0]"
            post = []
            if fade and d2 > 2:
                post += ["fade=t=in:st=0:d=0.5", f"fade=t=out:st={d2-0.5:.2f}:d=0.5"]
            if wm_clean and os.path.exists(FONT):
                wm_file = os.path.join(work, "watermark.txt")
                with open(wm_file, "w", encoding="utf-8") as f:
                    f.write(wm_clean.replace("\n", " ")[:80])
                post.append(f"drawtext=fontfile={FONT}:textfile={wm_file}:fontcolor=white@0.75:fontsize=h/28:"
                            f"x=w-tw-24:y=h-th-24:shadowcolor=black:shadowx=2:shadowy=2")
            fc += ";[v0]" + (",".join(post) if post else "null") + "[v]"
            fin = os.path.join(work, "fin.mp4")
            cmd = ["ffmpeg", "-y", "-i", current, "-filter_complex", fc, "-map", "[v]", "-map", "0:a?"]
            if a2 and fade and d2 > 2:
                cmd += ["-af", f"afade=t=in:st=0:d=0.5,afade=t=out:st={d2-0.5:.2f}:d=0.5"]
            cmd += ["-c:v", "libx264", "-preset", "medium", "-crf", "17", "-pix_fmt", "yuv420p",
                    "-c:a", "aac", "-b:a", "192k", fin]
            run(cmd)
            current = fin

        result = os.path.join(tempfile.gettempdir(), f"editado_{os.path.basename(work)}.mp4")
        shutil.copy(current, result)
        return result, "✅ Pronto! " + " ".join(notes) + " Toque nos três pontinhos do vídeo para baixar."
    except gr.Error:
        raise
    except Exception as e:
        raise gr.Error(f"Deu erro: {e}")

css = """
.gradio-container {background:#0b0818 !important; max-width:760px !important; margin:auto}
h1,h2,p,label,span {color:#eae6ff !important}
button.primary {background:linear-gradient(90deg,#6d4aff,#b04bff) !important; border:none !important; font-weight:700}
"""

DEFAULTS = dict(up=False, face=False, den=False, grade="Nenhum", aud=False, sil=False, hl=False, stab=False,
                sharp=False, vig=False, fmt=FORMATS[0], slow="1x", res="720p", mx=120, n_hl=6, seg=8, wm="", fade=False)

def parse_local(text):
    """Entende pedidos em português por palavras-chave (grátis, sem chave)."""
    t = text.lower()
    o = dict(DEFAULTS)
    has = lambda *ws: any(w in t for w in ws)
    if has("qualidade", "nitid", " hd", "aprimor", "upscale", "4k", "imagem"): o["up"] = o["sharp"] = True
    if has("rosto", "face", "cara do"): o["face"] = True
    if has("ruído", "ruido", "granulad"): o["den"] = True
    if has("preto e branco", "p&b"): o["grade"] = "Preto e branco"
    elif has("cinema", "filme"): o["grade"] = "Cinema (azul e laranja)"
    elif has("tv ", "esportiv", "transmiss"): o["grade"] = "TV esportiva"
    elif has("vibrante", "forte", "colorid", "cor ", "cores", "edit"): o["grade"] = "Edit vibrante"
    if has("áudio", "audio", "voz"): o["aud"] = True
    if has("silêncio", "silencio"): o["sil"] = True
    if has("melhores momentos", "lances", "highlights", "resumo", "gols", "jogadas"): o["hl"] = True
    m = re.search(r"(\d+)\s*(?:melhores\s*)?(lances|momentos|jogadas|gols|cortes)", t)
    if m: o["hl"] = True; o["n_hl"] = max(2, min(20, int(m.group(1))))
    m = re.search(r"(\d+)\s*(?:segundos|s)\s*cada", t)
    if m: o["seg"] = max(4, min(20, int(m.group(1))))
    if has("estabiliz", "tremen", "tremid"): o["stab"] = True
    if has("vinheta"): o["vig"] = True
    if has("tiktok", "vertical", "reels", "shorts", "9:16"): o["fmt"] = FORMATS[1]
    elif has("horizontal", "youtube", "16:9"): o["fmt"] = FORMATS[2]
    if has("câmera lenta", "camera lenta", "slow", "devagar"):
        o["slow"] = "0.75x" if has("0.75", "0,75") else "0.5x"
    if has("1080", "full hd"): o["res"] = "1080p"
    m = re.search(r"@[\w.]+", text)
    if m: o["wm"] = m.group(0)
    if has("fade") and not has("sem fade"): o["fade"] = True
    if has("profissional", "pro ", "edit de", "edit do"):
        o.update(up=True, sharp=True, vig=True, fade=True, aud=True)
        if o["grade"] == "Nenhum": o["grade"] = "Edit vibrante"
    if has("rápido", "rapido"): o["up"] = o["face"] = False
    if has("inteiro", "completo", "todo o vídeo", "todo o video"): o["mx"] = 3600
    m = re.search(r"primeiros?\s*(\d+)\s*(segundos|s|minutos|min)", t)
    if m: o["mx"] = int(m.group(1)) * (60 if m.group(2).startswith("min") else 1)
    return o

def parse_claude(text, key):
    """Opcional: usa a IA Claude (precisa de chave da API) para entender pedidos mais complicados."""
    prompt = ("Converta o pedido de edição de vídeo em JSON puro (sem texto extra) com estas chaves: "
              "up, face, den, aud, sil, hl, stab, sharp, vig, fade (true/false); "
              f"grade (um de {list(GRADES)}); fmt (um de {FORMATS}); slow (um de {SLOWS}); "
              "res ('720p' ou '1080p'); mx (segundos do vídeo a usar, até 3600); "
              "n_hl (2 a 20 lances); seg (4 a 20 segundos por lance); wm (texto da marca d'água ou ''). "
              "up=aprimorar qualidade com IA, face=restaurar rostos, den=tirar ruído, aud=limpar áudio, "
              "sil=cortar silêncios, hl=só os melhores momentos, stab=estabilizar, sharp=nitidez, vig=vinheta. "
              "Só ligue o que o pedido pedir.\n\nPedido: " + text)
    body = json.dumps({"model": "claude-sonnet-5-5", "max_tokens": 500,
                       "messages": [{"role": "user", "content": prompt}]}).encode()
    req = urllib.request.Request("https://api.anthropic.com/v1/messages", data=body, headers={
        "content-type": "application/json", "x-api-key": key, "anthropic-version": "2023-06-01"})
    reply = json.loads(urllib.request.urlopen(req, timeout=60).read())["content"][0]["text"]
    d = json.loads(reply[reply.index("{"): reply.rindex("}") + 1])
    o = dict(DEFAULTS)
    for k, v in d.items():
        if k in o and type(v) == type(o[k]):
            o[k] = v
    if o["grade"] not in GRADES: o["grade"] = "Nenhum"
    if o["fmt"] not in FORMATS: o["fmt"] = FORMATS[0]
    if o["slow"] not in SLOWS: o["slow"] = "1x"
    if o["res"] not in ("720p", "1080p"): o["res"] = "720p"
    o["mx"] = max(5, min(3600, o["mx"])); o["n_hl"] = max(2, min(20, o["n_hl"])); o["seg"] = max(4, min(20, o["seg"]))
    return o

def describe(o):
    p = []
    if o["hl"]: p.append(f"{o['n_hl']} melhores momentos de {o['seg']}s")
    if o["up"]: p.append("aprimorar qualidade")
    if o["face"]: p.append("restaurar rostos")
    if o["den"]: p.append("tirar ruído")
    if o["grade"] != "Nenhum": p.append("cor " + o["grade"])
    if o["stab"]: p.append("estabilizar")
    if o["sharp"]: p.append("nitidez")
    if o["vig"]: p.append("vinheta")
    if o["aud"]: p.append("limpar áudio")
    if o["sil"]: p.append("cortar silêncios")
    if o["slow"] != "1x": p.append("câmera lenta " + o["slow"])
    if o["fmt"] != FORMATS[0]: p.append(o["fmt"])
    if o["fade"]: p.append("fade")
    if o["wm"]: p.append("marca " + o["wm"])
    p.append(o["res"])
    if not o["hl"]: p.append(f"usando os primeiros {o['mx']}s")
    return ", ".join(p)

START = "💬 **Chat de edição.** Envie o vídeo, escreva o que quer e toque em Enviar."

def chat(video, text, key, log, progress=gr.Progress()):
    if not video:
        raise gr.Error("Envie um vídeo primeiro (caixa acima).")
    if not (text or "").strip():
        raise gr.Error("Escreva o que você quer que eu faça.")
    base = "" if log == START else log + "\n\n"
    base += f"🧑 **Você:** {text}"
    o, how = None, "regras"
    if (key or "").strip():
        try:
            o, how = parse_claude(text, key.strip()), "Claude"
        except Exception as e:
            how = f"regras (Claude falhou: {str(e)[:80]})"
    if o is None:
        o = parse_local(text)
    if o == DEFAULTS:
        result_log = base + "\n\n🤖 **IA:** Não entendi. Tente: *deixa mais nítido, cor forte, formato TikTok* ou *pega os 8 melhores lances e deixa em câmera lenta*."
        return None, result_log, "", result_log
    base += f"\n\n🤖 **IA:** Entendi ({how}): {describe(o)}. Editando..."
    path, msg = process(video, o["up"], o["face"], o["den"], o["grade"], o["aud"], o["sil"], o["hl"], o["stab"],
                        o["sharp"], o["vig"], o["fmt"], o["slow"], o["res"], o["mx"], o["n_hl"], o["seg"],
                        o["wm"], o["fade"], progress=progress)
    result_log = base + "\n\n🤖 **IA:** " + msg
    return path, result_log, "", result_log

with gr.Blocks(title="Vex Neymar Editor PRO", css=css, theme=gr.themes.Base(primary_hue="violet", neutral_hue="slate")) as demo:
    gr.Markdown("# ⚡ Vex Neymar Editor PRO\nEscreva o que você quer e o editor aplica os ajustes automaticamente.")
    vid = gr.Video(label="1) Seu vídeo")
    log = gr.Markdown(START)
    history = gr.State(START)
    msgbox = gr.Textbox(label="2) Peça aqui", lines=2,
                        placeholder="Ex: pega os 8 melhores lances, cor forte, formato TikTok, marca @meuperfil")
    send = gr.Button("🚀 Enviar", variant="primary")
    out = gr.Video(label="Vídeo editado")
    with gr.Accordion("🔑 Entender pedidos difíceis com Claude (opcional)", open=False):
        gr.Markdown("Sem chave, eu entendo palavras comuns (qualidade, cor, TikTok, lances, câmera lenta...). Com uma chave da API Claude, entendo frases livres. A chave só fica nesta sessão.")
        key = gr.Textbox(label="Chave da API Claude", type="password")
    send.click(chat, [vid, msgbox, key, history], [out, log, msgbox, history])
    msgbox.submit(chat, [vid, msgbox, key, history], [out, log, msgbox, history])

    with gr.Accordion("🎛️ Controles manuais (opcional)", open=False):
        recipe = gr.Dropdown(list(RECIPES), value="Personalizado", label="🎯 Receita pronta")
        with gr.Row():
            c_up = gr.Checkbox(True, label="✨ Melhorar imagem")
            c_face = gr.Checkbox(False, label="🙂 Realçar rostos")
            c_den = gr.Checkbox(False, label="🧹 Tirar ruído")
        with gr.Row():
            d_grade = gr.Dropdown(list(GRADES), value="Edit vibrante", label="🎨 Estilo de cor")
            d_fmt = gr.Dropdown(FORMATS, value=FORMATS[0], label="📱 Formato")
            d_slow = gr.Dropdown(SLOWS, value="1x", label="🐢 Velocidade")
        with gr.Row():
            c_stab = gr.Checkbox(False, label="🎥 Estabilizar")
            c_sharp = gr.Checkbox(True, label="🔍 Nitidez extra")
            c_vig = gr.Checkbox(False, label="🌑 Vinheta cinema")
            c_fade = gr.Checkbox(True, label="🌗 Fade")
        with gr.Row():
            c_aud = gr.Checkbox(True, label="🔊 Limpar áudio")
            c_sil = gr.Checkbox(False, label="✂️ Cortar silêncios")
            c_hl = gr.Checkbox(False, label="🏆 Melhores momentos")
        with gr.Row():
            n_hl = gr.Slider(2, 20, value=6, step=1, label="Quantos momentos")
            seg = gr.Slider(4, 20, value=8, step=1, label="Segundos de cada")
        with gr.Row():
            res = gr.Radio(["720p", "1080p"], value="720p", label="Resolução final")
            mx = gr.Slider(5, 3600, value=30, step=5, label="Usar só os primeiros X segundos")
        wm = gr.Textbox(label="💧 Marca d'água", placeholder="@seuperfil")
        btn = gr.Button("Editar com estes controles")
        msg = gr.Markdown()
        COMPS = [c_up, c_face, c_den, d_grade, c_aud, c_sil, c_hl, c_stab, c_sharp, c_vig, d_fmt, d_slow]
        def apply_recipe(name):
            r = RECIPES.get(name)
            return [gr.update() for _ in COMPS] if r is None else [gr.update(value=v) for v in r]
        recipe.change(apply_recipe, recipe, COMPS)
        btn.click(process, [vid, c_up, c_face, c_den, d_grade, c_aud, c_sil, c_hl, c_stab, c_sharp, c_vig,
                            d_fmt, d_slow, res, mx, n_hl, seg, wm, c_fade], [out, msg])

demo.queue(max_size=10).launch(server_name="0.0.0.0", server_port=int(os.environ.get("PORT", "7860")), share=False)
